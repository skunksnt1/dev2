package com.btg.pactual.hub.news.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class ImageDTO {
  private String url;
  private String caption;
  private Integer width;
  private Integer height;
  private String mimeType;
}
