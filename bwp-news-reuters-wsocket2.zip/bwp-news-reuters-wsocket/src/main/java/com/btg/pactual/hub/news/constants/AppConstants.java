package com.btg.pactual.hub.news.constants;

public final class AppConstants {
    // true => salva arquivo em data/mrn/ | false => grava no MongoDB
    public static final boolean SAVE_TO_FILE = false;
    public static final String SAVE_PATH = "data/mrn/";
    private AppConstants() {}
}
