package com.btg.pactual.hub.news.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class SourceDTO {
  private String provider; // RTO/MRN
  private String service;  // ELEKTRON_DD
  private String topic;    // BR, PT, ES...
}
