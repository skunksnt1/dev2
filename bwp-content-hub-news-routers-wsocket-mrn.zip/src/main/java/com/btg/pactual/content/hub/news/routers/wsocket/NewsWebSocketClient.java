package com.btg.pactual.content.hub.news.routers.wsocket.client;

import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.node.*;
import javax.net.ssl.*;
import java.io.*;
import java.net.URI;
import java.net.http.*;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.util.*;
import java.util.zip.GZIPInputStream;
import java.util.Base64;
import java.util.concurrent.*;

public class NewsWebSocketClient implements WebSocket.Listener {

    private HttpClient http = HttpClient.newHttpClient();
    private final String endpoint;
    private final String token;
    private WebSocket socket;
    private final ObjectMapper om = new ObjectMapper();
    private final File logFile = new File("news-output.txt");
    private final MrnAssembler assembler = new MrnAssembler();

    public NewsWebSocketClient(String endpoint, String token) {
        this.endpoint = endpoint;
        this.token = token;
    }

    public void connect() {
        try {
            write("[CONNECTING] " + endpoint);
            this.http = HttpClient.newBuilder()
                    .connectTimeout(Duration.ofSeconds(20))
                    .sslContext(insecureSSLContext())
                    .build();
            this.socket = http.newWebSocketBuilder()
                    .connectTimeout(Duration.ofSeconds(20))
                    .subprotocols("tr_json2")
                    .buildAsync(URI.create(endpoint), this).join();
            write("[READY] Connected");
        } catch (Exception e) {
            write("[ERROR] " + e.getMessage());
        }
    }

    @Override
    public void onOpen(WebSocket webSocket) {
        webSocket.request(1);
        try {
            String username = System.getenv("RTO_USERNAME");
            String login = ("{" +
                    "\"Domain\":\"Login\"," +
                    "\"ID\":1," +
                    "\"Key\":{\"Name\":\""+ username + "\",\"NameType\":\"AuthnToken\",\"Elements\":{\"ApplicationId\":\"256\",\"AuthenticationToken\":\""+ token + "\",\"Position\":\"127.0.0.1/net\"}}," +
                    "\"Refresh\":false}");
            write("SENT Login");
            webSocket.sendText(login, true);

            String sub = "{\"Domain\":\"NewsTextAnalytics\",\"ID\":2,\"Key\":{\"Name\":\"MRN_STORY\",\"Service\":\"ELEKTRON_DD\"}}";
            webSocket.sendText(sub, true);
            write("SENT Subscribe MRN_STORY");
        } catch (Exception e) {
            write("[LOGIN ERROR] " + e.getMessage());
        }
    }

    @Override
    public CompletionStage<?> onText(WebSocket webSocket, CharSequence data, boolean last) {
        try {
            String txt = data.toString();
            ArrayNode arr = (ArrayNode) om.readTree(txt);
            for (JsonNode msg : arr) {
                String type = msg.path("Type").asText("");
                if ("Ping".equalsIgnoreCase(type)) {
                    webSocket.sendText("{\"Type\":\"Pong\"}", true);
                    write("SENT Pong");
                    continue;
                }
                if ("Status".equalsIgnoreCase(type)) {
                    write("[STATUS] " + msg.toString());
                }
                if ("Refresh".equalsIgnoreCase(msg.path("Type").asText("")) &&
                    "NewsTextAnalytics".equalsIgnoreCase(msg.path("Domain").asText(""))) {
                    write("[REFRESH] " + msg.toString());
                }
                if ("Update".equalsIgnoreCase(msg.path("Type").asText("")) &&
                    "NewsTextAnalytics".equalsIgnoreCase(msg.path("Domain").asText(""))) {
                    JsonNode f = msg.path("Fields");
                    String guid = f.path("GUID").asText(null);
                    String fragment = f.path("FRAGMENT").isNull() ? null : f.path("FRAGMENT").asText(null);
                    int fragNum = f.path("FRAG_NUM").asInt(1);
                    int totSize = f.path("TOT_SIZE").asInt(0);
                    if (fragment != null) {
                        String news = assembler.addFragment(guid, fragment, fragNum, totSize);
                        if (news != null) {
                            write("[MRN COMPLETE] " + guid);
                            write(news);
                        }
                    }
                }
            }
        } catch (Exception e) {
            write("[PARSE ERROR] " + e.getMessage());
        }
        webSocket.request(1);
        return null;
    }

    private void write(String line) {
        try (FileWriter fw = new FileWriter(logFile, true)) {
            fw.write(line + System.lineSeparator());
        } catch (IOException ignored) {}
    }

    private SSLContext insecureSSLContext() {
        try {
            TrustManager[] trustAll = new TrustManager[]{new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] xcs, String s) {}
                public void checkServerTrusted(X509Certificate[] xcs, String s) {}
                public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            }};
            SSLContext ssl = SSLContext.getInstance("TLS");
            ssl.init(null, trustAll, new SecureRandom());
            return ssl;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    static class MrnAssembler {
        private static class FragState {
            final int total;
            int received = 0;
            final ByteArrayOutputStream buf = new ByteArrayOutputStream();
            FragState(int total) { this.total = total; }
        }
        private final Map<String, FragState> inFlight = new HashMap<>();
        public synchronized String addFragment(String guid, String b64, int fragNum, int totSize) throws Exception {
            if (guid == null || guid.isBlank() || b64 == null) return null;
            byte[] chunk = Base64.getDecoder().decode(b64);
            FragState st = inFlight.computeIfAbsent(guid, g -> new FragState(totSize > 0 ? totSize : chunk.length));
            st.buf.write(chunk);
            st.received += chunk.length;
            if (totSize > 0 && st.received < totSize) return null;
            byte[] zipped = st.buf.toByteArray();
            inFlight.remove(guid);
            try (GZIPInputStream gis = new GZIPInputStream(new ByteArrayInputStream(zipped))) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] tmp = new byte[8192];
                int n; while ((n = gis.read(tmp)) > 0) out.write(tmp, 0, n);
                return out.toString("UTF-8");
            }
        }
    }

    public static void main(String[] args) {
        String token = System.getenv("RDP_TOKEN");
        String endpoint = System.getenv().getOrDefault("WS_URL",
            "wss://us-east-1-aws-1-sm.optimized-pricing-api.refinitiv.net:443/WebSocket");
        new NewsWebSocketClient(endpoint, token).connect();
    }
}
