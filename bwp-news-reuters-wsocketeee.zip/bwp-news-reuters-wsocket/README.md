# bwp-news-reuters-wsocket

POC Spring Boot 3.2 + MongoDB para ingestão de notícias Reuters MRN via WebSocket.
Permite alternar entre gravar **em arquivo** (`data/mrn/`) e **direto no MongoDB** usando a constante `SAVE_TO_FILE`.

## Requisitos
- Java 17
- Maven 3.9+
- MongoDB 7+ (ou Docker)

### Subir Mongo com Docker
```bash
docker run -d --name mongo -p 27017:27017 mongo:7
```

## Rodar
```bash
mvn spring-boot:run
```
ou
```bash
mvn clean package && java -jar target/bwp-news-reuters-wsocket-0.0.1-SNAPSHOT.jar
```

## Teste rápido (POST manual)
```bash
curl -X POST http://localhost:8080/api/news/test \  -H "Content-Type: application/json" \  -d '{"altId":"nABCD123","language":"pt","headline":"Teste","body":"Corpo da notícia","audiences":["NP:TRNPT"]}'
```

Se `SAVE_TO_FILE=true`, um arquivo JSON será gravado em `data/mrn/`. Caso contrário, o documento irá para a coleção `news` no Mongo.
