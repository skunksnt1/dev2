package com.btg.pactual.hub.news.config;

import com.btg.pactual.hub.news.model.NewsDocument;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.index.Index;

import jakarta.annotation.PostConstruct;

@Configuration
public class MongoIndexesConfig {
  private final MongoTemplate template;
  public MongoIndexesConfig(MongoTemplate template) { this.template = template; }

  @PostConstruct
  public void ensureIndexes() {
    template.indexOps(NewsDocument.class).ensureIndex(
      new Index().on("id", Sort.Direction.ASC).unique()
    );
    template.indexOps(NewsDocument.class).ensureIndex(
      new Index().on("expireAt", Sort.Direction.ASC).expire(0)
    );
  }
}
