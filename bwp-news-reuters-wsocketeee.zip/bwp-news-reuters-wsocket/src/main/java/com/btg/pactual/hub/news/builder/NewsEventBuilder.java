package com.btg.pactual.hub.news.builder;

import com.btg.pactual.hub.news.dto.NewsEventDTO;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.List;
import java.util.stream.StreamSupport;

@Component
@RequiredArgsConstructor
public class NewsEventBuilder {
  private final ObjectMapper mapper;

  public NewsEventDTO fromMrn(String raw) {
    try {
      JsonNode n = mapper.readTree(raw);
      return NewsEventDTO.builder()
        .id(n.path("altId").asText())               // altId é chave da Reuters MRN
        .language(n.path("language").asText("pt"))
        .headline(n.path("headline").asText(null))
        .body(n.path("body").asText(""))
        .audiences(array(n.path("audiences")))
        .receivedAt(Instant.now())
        .build();
    } catch (Exception e) {
      throw new IllegalArgumentException("Payload MRN inválido", e);
    }
  }

  private static List<String> array(JsonNode node) {
    if (!node.isArray()) return List.of();
    return StreamSupport.stream(node.spliterator(), false)
      .map(JsonNode::asText).toList();
  }
}
