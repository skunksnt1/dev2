package com.btg.pactual.hub.news.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.index.IndexDirection;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.List;

@Document(collection = "news")
@CompoundIndexes({
    @CompoundIndex(name = "lang_received_idx", def = "{'language':1,'receivedAt':-1}"),
    @CompoundIndex(name = "text_idx", def = "{'headline':'text','body':'text'}")
})
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class NewsDocument {
  @Id
  private String mongoId;

  @Indexed(unique = true)
  private String id; // altId

  private String language;
  private String headline;
  private String body;

  private List<String> audiences;
  private Source source;
  private List<Image> images;

  @Indexed(direction = IndexDirection.DESCENDING)
  private Instant receivedAt;

  // TTL opcional (índice em expireAt)
  private Instant expireAt;

  @Data @Builder @NoArgsConstructor @AllArgsConstructor
  public static class Image {
    private String url;
    private String caption;
    private Integer width;
    private Integer height;
    private String mimeType;
  }

  @Data @Builder @NoArgsConstructor @AllArgsConstructor
  public static class Source {
    private String provider;
    private String service;
    private String topic;
  }
}
