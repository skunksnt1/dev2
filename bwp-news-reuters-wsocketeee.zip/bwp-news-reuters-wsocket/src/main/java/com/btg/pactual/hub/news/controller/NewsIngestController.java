package com.btg.pactual.hub.news.controller;

import com.btg.pactual.hub.news.service.NewsRoutingService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/news")
@RequiredArgsConstructor
public class NewsIngestController {

  private final NewsRoutingService routingService;

  /** Endpoint de teste para enviar JSON MRN cru e gravar em arquivo ou Mongo **/
  @PostMapping("/test")
  public ResponseEntity<String> ingest(@RequestBody String rawJson) {
    routingService.processIncomingJson(rawJson);
    return ResponseEntity.ok("OK");
  }
}
