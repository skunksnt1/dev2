package com.btg.pactual.hub.news.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import java.util.List;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class NewsEventDTO {
  @NotBlank private String id;         // altId
  private String language;             // pt|en|es
  private String headline;
  private String body;
  private List<String> audiences;
  private SourceDTO source;
  private List<ImageDTO> images;
  private Instant receivedAt;
}
