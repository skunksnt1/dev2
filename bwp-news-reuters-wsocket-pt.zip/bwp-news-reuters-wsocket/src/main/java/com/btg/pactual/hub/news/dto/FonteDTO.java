package com.btg.pactual.hub.news.dto;
import lombok.*; @Data @Builder @NoArgsConstructor @AllArgsConstructor
public class FonteDTO { public String provider; public String service; public String topic; }
