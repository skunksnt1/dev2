package com.btg.pactual.content.hub.news.routers.wsocket.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.btg.pactual.content.hub.news.routers.wsocket")
public class NewsWebSocketApplication {
    public static void main(String[] args) {
        SpringApplication.run(NewsWebSocketApplication.class, args);
    }
}
