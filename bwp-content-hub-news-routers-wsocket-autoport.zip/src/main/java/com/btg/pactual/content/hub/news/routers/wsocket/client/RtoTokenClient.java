package com.btg.pactual.content.hub.news.routers.wsocket.client;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;

public class RtoTokenClient {
    private final HttpClient http = HttpClient.newHttpClient();
    private final ObjectMapper om = new ObjectMapper();

    private final String baseUrl;
    private final String authPath;
    private final String username;
    private final String password;
    private final String clientId;
    private final String scope;

    private String accessToken;
    private long expiryEpochSeconds;
    private String refreshToken;

    public RtoTokenClient(String baseUrl, String authPath, String username, String password, String clientId, String scope) {
        this.baseUrl = baseUrl;
        this.authPath = authPath;
        this.username = username;
        this.password = password;
        this.clientId = clientId;
        this.scope = scope == null ? "" : scope;
    }

    public synchronized String getAccessToken() throws IOException, InterruptedException {
        long now = System.currentTimeMillis() / 1000L;
        if (accessToken != null && now < (expiryEpochSeconds - 30)) {
            return accessToken;
        }
        Map<String, String> body = new LinkedHashMap<>();
        body.put("username", username);
        body.put("password", password);
        body.put("client_id", clientId);
        body.put("grant_type", "password");
        body.put("takeExclusiveSignOnControl", "true");
        if (!scope.isBlank()) body.put("scope", scope);

        String form = formEncode(body);
        HttpRequest req = HttpRequest.newBuilder(URI.create(baseUrl + authPath))
                .timeout(Duration.ofSeconds(20))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(form))
                .build();

        HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() / 100 != 2)
            throw new IOException("Auth failed: HTTP " + resp.statusCode() + "\n" + resp.body());

        JsonNode json = om.readTree(resp.body());
        accessToken = json.path("access_token").asText();
        int expiresIn = json.path("expires_in").asInt(300);
        expiryEpochSeconds = (System.currentTimeMillis() / 1000L) + expiresIn;
        refreshToken = json.path("refresh_token").asText(null);
        return accessToken;
    }

    private String formEncode(Map<String, String> map) {
        StringBuilder sb = new StringBuilder();
        boolean first = true;
        for (var e : map.entrySet()) {
            if (!first) sb.append('&');
            sb.append(URLEncoder.encode(e.getKey(), StandardCharsets.UTF_8)).append('=')
              .append(URLEncoder.encode(e.getValue(), StandardCharsets.UTF_8));
            first = false;
        }
        return sb.toString();
    }
}
