package com.btg.pactual.content.hub.news.routers.wsocket.config;

import com.btg.pactual.content.hub.news.routers.wsocket.client.NewsWebSocketClient;
import com.btg.pactual.content.hub.news.routers.wsocket.client.RtoTokenClient;
import com.btg.pactual.content.hub.news.routers.wsocket.discovery.RdpDiscoveryClient;
import com.btg.pactual.content.hub.news.routers.wsocket.queue.FileQueueSink;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.beans.factory.annotation.Value;

@Configuration
public class WebSocketConfig {

    @Bean
    public RtoTokenClient tokenClient(
            @Value("${rto.username:}") String username,
            @Value("${rto.password:}") String password,
            @Value("${rto.clientId:}") String clientId,
            @Value("${rto.scope:trapi.streaming.news.read}") String scope,
            @Value("${rto.baseUrl:https://api.refinitiv.com}") String baseUrl,
            @Value("${rto.authPath:/auth/oauth2/v1/token}") String authPath
    ) {
        return new RtoTokenClient(baseUrl, authPath, username, password, clientId, scope);
    }

    @Bean
    public RdpDiscoveryClient discoveryClient(
            @Value("${rto.baseUrl:https://api.refinitiv.com}") String baseUrl,
            @Value("${rto.discoveryPath:/streaming/pricing/v1/}") String discoveryPath
    ) {
        return new RdpDiscoveryClient(baseUrl, discoveryPath);
    }

    @Bean
    public FileQueueSink fileQueueSink(@Value("${output.file:news-output.txt}") String filename) {
        return new FileQueueSink(filename);
    }

    @Bean
    public NewsWebSocketClient newsWebSocketClient(
            @Value("${news.wsUrl:}") String wsUrlOverride,
            @Value("${news.reconnectSeconds:30}") int reconnectSeconds,
            @Value("${news.ric:MRN_STORY}") String mrnRic,
            @Value("${news.allowInsecureOnRetry:true}") boolean allowInsecureOnRetry,
            RtoTokenClient tokenClient,
            RdpDiscoveryClient discovery,
            FileQueueSink sink
    ) {
        return new NewsWebSocketClient(wsUrlOverride, reconnectSeconds, mrnRic, allowInsecureOnRetry, tokenClient, discovery, sink);
    }

    @Bean
    public ApplicationRunner startWs(NewsWebSocketClient client) {
        return args -> client.connect();
    }
}
