package com.btg.pactual.content.hub.news.routers.wsocket.client;

import com.btg.pactual.content.hub.news.routers.wsocket.discovery.RdpDiscoveryClient;
import com.btg.pactual.content.hub.news.routers.wsocket.queue.FileQueueSink;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

public class NewsWebSocketClient implements WebSocket.Listener, AutoCloseable {

    private HttpClient http = HttpClient.newHttpClient();
    private final String wsUrlOverride;
    private final int reconnectSeconds;
    private final String mrnRic;
    private final boolean allowInsecureOnRetry;
    private final RtoTokenClient tokenClient;
    private final RdpDiscoveryClient discovery;
    private final FileQueueSink sink;
    private volatile WebSocket socket;
    private volatile boolean closed = false;

    private static final String CLOUD_WS = "wss://api.refinitiv.com/wsapi/v1";

    public NewsWebSocketClient(String wsUrlOverride, int reconnectSeconds, String mrnRic, boolean allowInsecureOnRetry,
                               RtoTokenClient tokenClient, RdpDiscoveryClient discovery, FileQueueSink sink) {
        this.wsUrlOverride = wsUrlOverride == null ? "" : wsUrlOverride;
        this.reconnectSeconds = reconnectSeconds;
        this.mrnRic = mrnRic;
        this.allowInsecureOnRetry = allowInsecureOnRetry;
        this.tokenClient = tokenClient;
        this.discovery = discovery;
        this.sink = sink;
    }

    private static SSLContext insecureSSLContext() {
        try {
            TrustManager[] trustAll = new TrustManager[]{ new X509TrustManager() {
                public void checkClientTrusted(X509Certificate[] xcs, String s) {}
                public void checkServerTrusted(X509Certificate[] xcs, String s) {}
                public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
            }};
            SSLContext ssl = SSLContext.getInstance("TLS");
            ssl.init(null, trustAll, new SecureRandom());
            return ssl;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static URI normalizeHosted(String endpoint) {
        if (endpoint == null) endpoint = "";
        endpoint = endpoint.trim();
        if (endpoint.startsWith("https://")) endpoint = "wss://" + endpoint.substring(8);
        else if (endpoint.startsWith("http://")) endpoint = "ws://" + endpoint.substring(7);
        else if (!endpoint.startsWith("ws")) endpoint = "wss://" + endpoint;
        if (!endpoint.endsWith("/WebSocket")) {
            if (endpoint.endsWith("/")) endpoint = endpoint.substring(0, endpoint.length()-1);
            endpoint = endpoint + "/WebSocket";
        }
        return URI.create(endpoint);
    }

    public void connect() {
        try {
            String token = tokenClient.getAccessToken();

            java.util.ArrayList<URI> candidates = new java.util.ArrayList<>();
            if (!wsUrlOverride.isBlank()) {
                candidates.add(normalizeHosted(wsUrlOverride));
            } else {
                List<String> fromDisc = discovery.resolveWebSocketEndpoints(token);
                for (String ep : fromDisc) candidates.add(normalizeHosted(ep));
                candidates.add(URI.create(CLOUD_WS)); // fallback cloud
            }

            Exception lastError = null;
            for (URI candidate : candidates) {
                try {
                    sink.appendLine("[CONNECTING] " + candidate);
                    this.http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(20)).build();
                    WebSocket.Builder builder = http.newWebSocketBuilder()
                            .connectTimeout(Duration.ofSeconds(20))
                            .subprotocols("tr_json2");
                    this.socket = builder.buildAsync(candidate, this).join();
                    sink.appendLine("[OPEN] Connected to " + candidate);
                    return;
                } catch (Exception e1) {
                    lastError = e1;
                    sink.appendLine("[HANDSHAKE FAIL] " + e1.getClass().getName() + " -> " + (e1.getMessage()==null?e1.toString():e1.getMessage()));
                    int port = candidate.getPort();
                    if (allowInsecureOnRetry && port != -1 && port != 443) {
                        try {
                            sink.appendLine("[RETRY] Insecure SSL to " + candidate);
                            this.http = HttpClient.newBuilder()
                                    .sslContext(insecureSSLContext())
                                    .connectTimeout(Duration.ofSeconds(20))
                                    .build();
                            WebSocket.Builder builder = http.newWebSocketBuilder()
                                    .connectTimeout(Duration.ofSeconds(20))
                                    .subprotocols("tr_json2");
                            this.socket = builder.buildAsync(candidate, this).join();
                            sink.appendLine("[OPEN] Connected (insecure) to " + candidate);
                            return;
                        } catch (Exception e2) {
                            lastError = e2;
                            sink.appendLine("[RETRY FAIL] " + e2.getClass().getName() + " -> " + (e2.getMessage()==null?e2.toString():e2.getMessage()));
                        }
                    }
                }
            }
            throw lastError != null ? lastError : new IllegalStateException("No WS candidates worked");
        } catch (Exception e) {
            try { sink.appendLine("[ERROR] " + e.getMessage()); } catch (Exception ignore) {}
            scheduleReconnect();
        }
    }

    @Override
    public void onOpen(WebSocket webSocket) {
        webSocket.request(1);
        try {
            sink.appendLine("[READY] WebSocket Open");
            String token = tokenClient.getAccessToken();

            String login = ("{"ID":1,"Domain":"Login","Key":{"Elements":{" +
                    ""ApplicationId":"256"," +
                    ""Position":"127.0.0.1/net"," +
                    ""AuthenticationToken":"" + token + """ +
                    "}}}");
            webSocket.sendText(login, true);

            String sub = ("{"ID":2,"Domain":"NewsTextAnalytics","Key":{"Name":"" + mrnRic + ""}}");
            webSocket.sendText(sub, true);
            sink.appendLine("[LOGIN + SUBSCRIBE] enviado (" + mrnRic + ")");
        } catch (Exception ignored) {}
    }

    @Override
    public CompletionStage<?> onText(WebSocket webSocket, CharSequence data, boolean last) {
        try { sink.appendLine("[MSG] " + data); } catch (Exception ignored) {}
        webSocket.request(1);
        return null;
    }

    @Override
    public CompletionStage<?> onClose(WebSocket webSocket, int statusCode, String reason) {
        try { sink.appendLine("[CLOSE] " + statusCode + ": " + reason); } catch (Exception ignored) {}
        scheduleReconnect();
        return CompletableFuture.completedFuture(null);
    }

    @Override
    public void onError(WebSocket webSocket, Throwable error) {
        try { sink.appendLine("[ERROR] " + (error.getMessage() == null ? error.toString() : error.getMessage())); } catch (Exception ignored) {}
        scheduleReconnect();
    }

    private void scheduleReconnect() {
        if (closed) return;
        try { Thread.sleep(reconnectSeconds * 1000L); } catch (InterruptedException ignored) {}
        connect();
    }

    @Override
    public void close() throws Exception {
        closed = true;
        if (socket != null) socket.abort();
    }
}
