package com.btg.pactual.content.hub.news.routers.wsocket.discovery;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class RdpDiscoveryClient {
    private final HttpClient http = HttpClient.newHttpClient();
    private final ObjectMapper om = new ObjectMapper();
    private final String baseUrl;
    private final String discoveryPath;

    public RdpDiscoveryClient(String baseUrl, String discoveryPath) {
        this.baseUrl = baseUrl;
        this.discoveryPath = discoveryPath;
    }

    public List<String> resolveWebSocketEndpoints(String bearerToken) throws IOException, InterruptedException {
        HttpRequest req = HttpRequest.newBuilder(URI.create(baseUrl + discoveryPath))
                .timeout(Duration.ofSeconds(20))
                .header("Authorization", "Bearer " + bearerToken)
                .build();
        HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() / 100 != 2) return List.of();

        JsonNode root = om.readTree(resp.body());
        List<String> out = new ArrayList<>();
        if (root.has("services") && root.get("services").isArray()) {
            for (JsonNode s : root.get("services")) {
                String host = s.path("endpoint").asText("");
                int port = s.path("port").asInt(443);
                String transport = s.path("transport").asText("");
                if ("websocket".equalsIgnoreCase(transport) && !host.isBlank()) {
                    out.add("wss://" + host + ":" + port + "/WebSocket");
                }
            }
        }
        return out;
    }

    public Optional<String> resolveWebSocketEndpoint(String bearerToken) throws IOException, InterruptedException {
        List<String> list = resolveWebSocketEndpoints(bearerToken);
        return list.isEmpty() ? Optional.empty() : Optional.of(list.get(0));
    }
}
