package com.btg.pactual.content.hub.news.routers.wsocket.controller;

import com.btg.pactual.content.hub.news.routers.wsocket.service.NewsService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class NewsController {
    private final NewsService service;
    public NewsController(NewsService service) { this.service = service; }

    @GetMapping("/news/test")
    public String test() {
        try {
            service.process("Hello from controller");
            return "OK";
        } catch (Exception e) {
            return "ERR: " + e.getMessage();
        }
    }
}
