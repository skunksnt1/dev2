package com.btg.pactual.hub.news.config;

import com.btg.pactual.hub.news.util.AwsSecretLoader;
import com.fasterxml.jackson.databind.JsonNode;
import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.management.JMXConnectionPoolListener;
import lombok.extern.slf4j.Slf4j;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.text.MessageFormat;

@Slf4j
@Configuration
public class MongoConfig {

    private static final String DEFAULT_CHB_DATABASE = "content-hub";
    private static final String DEFAULT_NEWS_DATABASE = "content-hub-news";

    public static final String MONGO_CLIENT_NEWS = "MONGO_CLIENT_NEWS";
    public static final String MONGO_TEMPLATE_NEWS = "MONGO_TEMPLATE_NEWS";

    public static final String MONGO_CLIENT_CHB = "MONGO_CLIENT_CHB";
    public static final String MONGO_TEMPLATE_CHB = "MONGO_TEMPLATE_CHB";

    private static final String CHB_SECRET_NAME = "lcontenthub";
    private static final String NEWS_SECRET_NAME = "lcontenthubnews";

    @Value("${btg.aws.secrets.manager.region}")
    private String secretManagerRegion;

    @Value("${mongodb.chb.uri}")
    private String chbTemplateConnectionString;

    @Value("${mongodb.news.uri}")
    private String newsTemplateConnectionString;

    public MongoClientSettings buildMongoClientSettings(String awsSecretName, String secretManagerRegion, String connectionTemplateUri) {

        JMXConnectionPoolListener connectionPoolListener = new JMXConnectionPoolListener();

        JsonNode userInfo = AwsSecretLoader.getAwsSecret(secretManagerRegion, awsSecretName);
        String username = userInfo.get("username").asText();
        String password = userInfo.get("password").asText();
        String connectionString = MessageFormat.format(connectionTemplateUri, username, password);

        if (log.isDebugEnabled()) {
            log.debug("# CRIANDO CONEXAO COM MONGODB");
            log.debug("# - USER:{}", username);
        }

        PojoCodecProvider pcp = PojoCodecProvider.builder().automatic(true).build();

        CodecRegistry pojoCodecRegistry = CodecRegistries.fromRegistries(MongoClientSettings.getDefaultCodecRegistry(),
                CodecRegistries.fromProviders(pcp));

        return MongoClientSettings.builder().applyConnectionString(new ConnectionString(connectionString))
                .applyToConnectionPoolSettings(builder -> builder.addConnectionPoolListener(connectionPoolListener))
                .codecRegistry(pojoCodecRegistry).build();
    }

    @Primary
    @Qualifier(MONGO_CLIENT_NEWS)
    @Bean
    public MongoClient mongoClientNews() {
        return MongoClients.create(buildMongoClientSettings(NEWS_SECRET_NAME, secretManagerRegion, newsTemplateConnectionString));
    }

    @Qualifier(MONGO_CLIENT_CHB)
    @Bean
    public MongoClient mongoClientChb() {
        return MongoClients.create(buildMongoClientSettings(CHB_SECRET_NAME, secretManagerRegion, chbTemplateConnectionString));
    }

    @Primary
    @Bean(name = MONGO_TEMPLATE_NEWS)
    public MongoTemplate mongoTemplateNews() {
        return new MongoTemplate(mongoClientNews(), DEFAULT_NEWS_DATABASE);
    }

    @Bean(name = MONGO_TEMPLATE_CHB)
    public MongoTemplate mongoTemplateChb() {
        return new MongoTemplate(mongoClientChb(), DEFAULT_CHB_DATABASE);
    }
}
