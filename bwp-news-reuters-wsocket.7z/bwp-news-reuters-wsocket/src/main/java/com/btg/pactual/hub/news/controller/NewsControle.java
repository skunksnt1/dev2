package com.btg.pactual.hub.news.controller;

import com.btg.pactual.hub.news.model.NewsDocumento;
import com.btg.pactual.hub.news.repository.NewsRepositorio;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/news")
@RequiredArgsConstructor
public class NewsControle {

    private final NewsRepositorio repo;

    @GetMapping("/ultimas")
    public ResponseEntity<List<NewsDocumento>> ultimas() {
        List<NewsDocumento> noticias = repo
            .findAll(PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "receivedAt")))
            .getContent();
        return ResponseEntity.ok(noticias);
    }
}
