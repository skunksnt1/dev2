# bwp-news-reuters-wsocket (Boot 2.3.12, Java 11, AWS Secrets)

- Spring Boot 2.3.12.RELEASE
- Java 11
- AWS Secrets Manager para usuário/senha do Mongo
- Banco: `content-hub-news`
- Coleção: `news-reuters`
- Swagger UI (Boot 2): `/swagger-ui.html`

## Variáveis necessárias
- `AWS_REGION` (opcional, default `us-east-1`)
- `AWS` credenciais via DefaultAWSCredentialsProviderChain (env vars, profile, IAM, etc.)
- `MONGODB_NEWS_URI_TEMPLATE` e `MONGODB_CHB_URI_TEMPLATE` com placeholders `{0}` e `{1}`

Exemplo:
```
MONGODB_NEWS_URI_TEMPLATE='mongodb://{0}:{1}@localhost:27017/content-hub-news'
MONGODB_CHB_URI_TEMPLATE='mongodb://{0}:{1}@localhost:27017/content-hub'
```

Secrets esperados no AWS Secrets Manager:
- `lcontenthubnews` -> {"username":"user","password":"pass"}
- `lcontenthub`     -> {"username":"user","password":"pass"}

## Rodar
```bash
mvn spring-boot:run
```

## Endpoint
```
GET http://localhost:8080/api/news/ultimas
```
Retorna as 10 últimas notícias de `content-hub-news.news-reuters`.
