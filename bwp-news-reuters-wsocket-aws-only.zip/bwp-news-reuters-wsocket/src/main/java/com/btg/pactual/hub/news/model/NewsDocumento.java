package com.btg.pactual.hub.news.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.IndexDirection;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.List;

@Document(collection = "news-reuters")
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class NewsDocumento {
  @Id
  private String mongoId;

  @Indexed(unique = true)
  private String id; // altId

  private String language;
  private String headline;
  private String body;
  private List<String> audiences;

  @Indexed(direction = IndexDirection.DESCENDING)
  private Instant receivedAt;
}
