# bwp-news-reuters-wsocket (AWS-only)

- Spring Boot 2.3.12.RELEASE (Java 11)
- Mongo via **AWS Secrets Manager** (sem fallback local)
- Banco: `content-hub-news`
- Coleção: `news-reuters`
- Swagger UI (Boot 2.x): `/swagger-ui.html`

## Requisitos
- Variável **obrigatória**: `AWS_REGION`
- Variáveis **obrigatórias** (templates de URI com `{0}` e `{1}`):
  - `MONGODB_NEWS_URI_TEMPLATE` (ex.: `mongodb://{0}:{1}@host:27017/content-hub-news`)
  - `MONGODB_CHB_URI_TEMPLATE`  (ex.: `mongodb://{0}:{1}@host:27017/content-hub`)

- Secrets no AWS Secrets Manager:
  - `lcontenthubnews` → `{"username":"...", "password":"..."}`
  - `lcontenthub`     → `{"username":"...", "password":"..."}`

## Rodar
```bash
export AWS_REGION=sa-east-1
export MONGODB_NEWS_URI_TEMPLATE='mongodb://{0}:{1}@seu-host:27017/content-hub-news'
export MONGODB_CHB_URI_TEMPLATE='mongodb://{0}:{1}@seu-host:27017/content-hub'

mvn spring-boot:run
```

## Endpoint
- `GET /api/news/ultimas` → últimas 10 de `content-hub-news.news-reuters`
- `GET /health`
