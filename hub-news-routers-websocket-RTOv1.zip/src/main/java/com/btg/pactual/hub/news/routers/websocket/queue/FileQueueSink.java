package com.btg.pactual.hub.news.routers.websocket.queue;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class FileQueueSink {
    private final Path file;
    private final DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public FileQueueSink(String filename) {
        try {
            this.file = Path.of(filename);
            if (!Files.exists(file)) Files.createFile(file);
            appendLine("===== START at " + LocalDateTime.now().format(fmt) + " =====");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public synchronized void appendLine(String line) throws IOException {
        Files.writeString(file, line + System.lineSeparator(), StandardOpenOption.APPEND);
    }
}
