package com.btg.pactual.hub.news.routers.websocket.client;

import com.btg.pactual.hub.news.routers.websocket.discovery.RdpDiscoveryClient;
import com.btg.pactual.hub.news.routers.websocket.queue.FileQueueSink;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.time.Duration;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

public class NewsWebSocketClient implements WebSocket.Listener, AutoCloseable {

    private final HttpClient http = HttpClient.newHttpClient();
    private final String wsUrlOverride;
    private final int reconnectSeconds;
    private final RtoTokenClient tokenClient;
    private final RdpDiscoveryClient discovery;
    private final FileQueueSink sink;
    private volatile WebSocket socket;
    private volatile boolean closed = false;

    public NewsWebSocketClient(String wsUrlOverride, int reconnectSeconds, RtoTokenClient tokenClient, RdpDiscoveryClient discovery, FileQueueSink sink) {
        this.wsUrlOverride = wsUrlOverride == null ? "" : wsUrlOverride;
        this.reconnectSeconds = reconnectSeconds;
        this.tokenClient = tokenClient;
        this.discovery = discovery;
        this.sink = sink;
    }

    public void connect() {
        try {
            String endpoint = wsUrlOverride;
            String token = tokenClient.getAccessToken();
            if (endpoint == null || endpoint.isBlank()) {
                endpoint = discovery.resolveWebSocketEndpoint(token).orElseThrow(() -> new IllegalStateException("Discovery não retornou endpoint WS. Defina WS_URL."));
            }
            WebSocket.Builder builder = http.newWebSocketBuilder().connectTimeout(Duration.ofSeconds(20));
            builder.header("Authorization", "Bearer " + token);
            this.socket = builder.buildAsync(URI.create(endpoint), this).join();
            sink.appendLine("[OPEN] Connected to " + endpoint);

            // Exemplo de subscribe (ajuste para seu domínio/tópico)
            // String sub = "{"Type":"Subscribe","Domains":["News"]}";
            // this.socket.sendText(sub, true);
        } catch (Exception e) {
            try { sink.appendLine("[ERROR] " + e.getMessage()); } catch (Exception ignored) {}
            scheduleReconnect();
        }
    }

    private void scheduleReconnect() {
        if (closed) return;
        try { sink.appendLine("[RECONNECT] New attempt in " + reconnectSeconds + "s"); } catch (Exception ignored) {}
        try { Thread.sleep(reconnectSeconds * 1000L); } catch (InterruptedException ignored) {}
        connect();
    }

    @Override
    public void onOpen(WebSocket webSocket) {
        webSocket.request(1);
        try { sink.appendLine("[READY] WebSocket Open"); } catch (Exception ignored) {}
    }

    @Override
    public CompletionStage<?> onText(WebSocket webSocket, CharSequence data, boolean last) {
        try { sink.appendLine("[MSG] " + data); } catch (Exception ignored) {}
        webSocket.request(1);
        return null;
    }

    @Override
    public CompletionStage<?> onClose(WebSocket webSocket, int statusCode, String reason) {
        try { sink.appendLine("[CLOSE] " + statusCode + ": " + reason); } catch (Exception ignored) {}
        scheduleReconnect();
        return CompletableFuture.completedFuture(null);
    }

    @Override
    public void onError(WebSocket webSocket, Throwable error) {
        try { sink.appendLine("[ERROR] " + (error.getMessage() == null ? error.toString() : error.getMessage())); } catch (Exception ignored) {}
        scheduleReconnect();
    }

    @Override
    public void close() throws Exception {
        closed = true;
        if (socket != null) socket.abort();
    }
}
