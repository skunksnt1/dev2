package com.btg.pactual.hub.news.routers.websocket.discovery;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Optional;

public class RdpDiscoveryClient {
    private final HttpClient http = HttpClient.newHttpClient();
    private final ObjectMapper om = new ObjectMapper();
    private final String baseUrl;
    private final String discoveryPath;

    public RdpDiscoveryClient(String baseUrl, String discoveryPath) {
        this.baseUrl = baseUrl;
        this.discoveryPath = discoveryPath;
    }

    /** Retorna uma URL wss:// a partir da resposta de discovery (primeiro endpoint websocket encontrado). */
    public Optional<String> resolveWebSocketEndpoint(String bearerToken) throws IOException, InterruptedException {
        HttpRequest req = HttpRequest.newBuilder(URI.create(baseUrl + discoveryPath))
                .timeout(Duration.ofSeconds(20))
                .header("Authorization", "Bearer " + bearerToken)
                .build();
        HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() / 100 != 2) {
            return Optional.empty();
        }
        JsonNode root = om.readTree(resp.body());

        // Estruturas possíveis variam; tentamos heurísticas comuns
        // 1) endpoints[...]{transport: websocket, endpoint/host, port}
        if (root.has("endpoints") && root.get("endpoints").isArray()) {
            for (JsonNode ep : root.get("endpoints")) {
                String transport = ep.path("transport").asText("");
                if ("websocket".equalsIgnoreCase(transport)) {
                    String host = ep.path("endpoint").asText(ep.path("host").asText(""));
                    int port = ep.path("port").asInt(443);
                    if (!host.isBlank()) return Optional.of("wss://" + host + ":" + port);
                }
            }
        }
        // 2) services[0].endpoint or host
        if (root.has("services") && root.get("services").isArray() && root.get("services").size() > 0) {
            JsonNode s = root.get("services").get(0);
            String host = s.path("endpoint").asText(s.path("host").asText(""));
            int port = s.path("port").asInt(443);
            if (!host.isBlank()) return Optional.of("wss://" + host + ":" + port);
        }
        return Optional.empty();
    }
}
