package com.btg.pactual.hub.news.routers.websocket.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.btg.pactual.hub.news.routers.websocket")
public class NewsWebSocketApplication {
    public static void main(String[] args) {
        SpringApplication.run(NewsWebSocketApplication.class, args);
    }
}
