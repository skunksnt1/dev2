# hub-news-routers-websocket (RTO v1)

Cliente WebSocket (Java 21 + Spring Boot) com autenticação **RTO v1** e (opcional) **Discovery** para obter endpoint WebSocket.
Mensagens recebidas são gravadas em arquivo (simulando fila).

## Executar
```bash
mvn spring-boot:run
# ou
mvn clean package
java -jar target/hub-news-routers-websocket-1.1.0-RTOv1.jar
```

## Variáveis esperadas (RTO v1)
```
RTO_USERNAME=Machine-ID
RTO_PASSWORD=RTO-Password
RTO_CLIENTID=App-Key
RTO_SCOPE=trapi.streaming.pricing.read

RDP_BASE_URL=https://api.refinitiv.com
RDP_AUTH_URL=/auth/oauth2/v1/token
RDP_DISCOVERY_URL=/streaming/pricing/v1/
# Opcional: WS_URL=wss://<endpoint> (se definido, Discovery é ignorado)
OUTPUT_FILE=news-output.txt
RECONNECT_MAX_SECONDS=30
```
