# bwp-content-hub-news-ema-consumer

EMA (RTSDK Java) Consumer para **Machine Readable News (MRN)** com gravação em arquivo.

## Pré-requisitos
- Java 21 (JDK)
- Maven 3.9+
- **RTSDK Java (EMA)** instalado no seu repositório Maven **OU** disponível em um repositório interno.
  - Se você tem o JAR local (ex.: `ema-3.7.0.0.jar`), instale assim:
    ```bash
    mvn install:install-file -Dfile=/caminho/para/ema-3.7.0.0.jar       -DgroupId=com.refinitiv -DartifactId=ema -Dversion=3.7.0.0 -Dpackaging=jar
    ```

## Configuração
Edite `src/main/resources/EmaConfig.xml` **ou** exporte as variáveis abaixo para usar RTO v1:
```bash
export RTO_CLIENTID="App-Key"
export RTO_USERNAME="Machine-ID"
export RTO_PASSWORD="RTO-Password"
export OUTPUT_FILE="news-output.txt"
export MRN_SERVICE="ELEKTRON_DD"    # ajuste conforme seu ambiente
export MRN_ITEM="MRN_STORY"
```

## Executar
```bash
mvn -q -e -DskipTests package
mvn -q exec:java -Dexec.mainClass="com.btg.pactual.content.hub.news.ema.EmaMrnConsumer"
# ou: java -cp target/bwp-content-hub-news-ema-consumer-1.0.0.jar:<sua-ema.jar> com.btg.pactual.content.hub.news.ema.EmaMrnConsumer
```

## Notas
- O `EmaConfig.xml` está preparado para **RDP Cloud (api.refinitiv.com:443)** usando **RTO v1**.
- Para ambientes **Hosted/ADS** (porta 14002, etc.), ajuste o `Channel` no XML para apontar o `Host/Port` correto
  e, se necessário, desabilite `EnableSessionManagement`.
- As mensagens MRN serão gravadas no arquivo definido em `OUTPUT_FILE` (padrão `news-output.txt`).
