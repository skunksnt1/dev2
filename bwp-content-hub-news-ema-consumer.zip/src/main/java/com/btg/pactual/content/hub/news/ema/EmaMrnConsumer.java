package com.btg.pactual.content.hub.news.ema;

import com.refinitiv.ema.access.*;
import com.refinitiv.ema.rdm.EmaRdm;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class EmaMrnConsumer {

    public static void main(String[] args) throws Exception {
        String service = System.getenv().getOrDefault("MRN_SERVICE", "ELEKTRON_DD");
        String item = System.getenv().getOrDefault("MRN_ITEM", "MRN_STORY");
        String outFile = System.getenv().getOrDefault("OUTPUT_FILE", "news-output.txt");

        FileSink sink = new FileSink(outFile);
        sink.write("===== EMA MRN CONSUMER START =====");

        OmmConsumerConfig config = EmaFactory.createOmmConsumerConfig().config("EmaConfig.xml").consumerName("Consumer_1");

        try (OmmConsumer consumer = EmaFactory.createOmmConsumer(config, new AppClient(sink))) {
            ReqMsg req = EmaFactory.createReqMsg()
                    .serviceName(service)
                    .name(item)
                    .domainType(EmaRdm.MMT_NEWS);
            long handle = consumer.registerClient(req, new AppClient(sink));
            sink.write("[SUBSCRIBE] service=" + service + " item=" + item + " domain=MMT_NEWS");

            // Loop simples; em produção use um mecanismo de lifecycle/threads adequado
            Thread.sleep(5 * 60 * 1000);
            consumer.unregister(handle);
        }
    }

    static class AppClient implements OmmConsumerClient {
        private final FileSink sink;
        AppClient(FileSink sink) { this.sink = sink; }

        @Override
        public void onRefreshMsg(RefreshMsg refreshMsg, OmmConsumerEvent event) {
            sink.write("[REFRESH] " + refreshMsg);
        }

        @Override
        public void onUpdateMsg(UpdateMsg updateMsg, OmmConsumerEvent event) {
            sink.write("[UPDATE] " + updateMsg);
        }

        @Override
        public void onStatusMsg(StatusMsg statusMsg, OmmConsumerEvent event) {
            sink.write("[STATUS] " + statusMsg);
        }
    }

    static class FileSink {
        private final Path path;
        private final DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        FileSink(String file) {
            this.path = Path.of(file);
            try {
                if (!Files.exists(path)) Files.createFile(path);
                write("= START " + LocalDateTime.now().format(fmt));
            } catch (IOException e) { throw new RuntimeException(e); }
        }
        synchronized void write(String line) {
            try { Files.writeString(path, line + System.lineSeparator(), java.nio.file.StandardOpenOption.APPEND); }
            catch (IOException e) { e.printStackTrace(); }
        }
    }
}
