package com.btg.pactual.hub.news.controller;

import com.btg.pactual.hub.news.dto.NewsDTO;
import com.btg.pactual.hub.news.service.NewsMongoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/news")
public class NewsController {

    @Autowired
    private NewsMongoService service;

    @GetMapping("/recent")
    public List<NewsDTO> getRecentNews() {
        return service.getRecentNews();
    }
}