package com.btg.pactual.hub.news.config;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;

@Configuration
public class MongoConfig {

    private static final Logger log = LoggerFactory.getLogger(MongoConfig.class);

    private static final String CONNECTION_STRING =
            "mongodb+srv://lcontenthubnews:6jbRA6BEgJ6j@news-mongo-dev2-pl-0.loing.mongodb.net/";
    private static final String DATABASE_NAME = "content-hub-news";

    @Bean
    public MongoTemplate mongoTemplate() {
        try {
            log.info("[MONGO-CONNECT] Tentando conectar ao MongoDB...");
            MongoClient client = MongoClients.create(CONNECTION_STRING);

            // Teste simples: listar bancos pra confirmar a conexão
            client.listDatabaseNames().first();

            log.info("[MONGO-CONNECT] ✅ Conectado com sucesso ao banco: {}", DATABASE_NAME);
            return new MongoTemplate(client, DATABASE_NAME);
        } catch (Exception e) {
            log.error("[MONGO-CONNECT] ❌ Falha ao conectar ao MongoDB: {}", e.getMessage(), e);
            throw e;
        }
    }
}
