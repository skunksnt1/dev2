package com.btg.pactual.hub.news.dto;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

@Document(collection = "rauters-news")
public class NewsDTO {

    @Id
    private String id;
    private String rawJson;
    private LocalDateTime createdAt = LocalDateTime.now();

    public NewsDTO() {}

    public NewsDTO(String rawJson) {
        this.rawJson = rawJson;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRawJson() {
        return rawJson;
    }

    public void setRawJson(String rawJson) {
        this.rawJson = rawJson;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
