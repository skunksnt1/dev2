package com.btg.pactual.hub.news.routers.websocket.client;

import com.btg.pactual.hub.news.FileQueueSink;
import com.btg.pactual.hub.news.MrnFragmentReassembler;
import com.btg.pactual.hub.news.RtoTokenClient;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.zip.GZIPInputStream;

public class NewsWebSocketClient implements WebSocket.Listener, AutoCloseable {

    private volatile WebSocket socket;
    private volatile boolean closed = false;
    private volatile boolean loginOpen = false;

    // Reagrupador de fragments (por GUID ou fallback)
    private final MrnFragmentReassembler reassembler = new MrnFragmentReassembler(60);

    // Contador e chave temporária para mensagens que chegam sem GUID
    private final AtomicInteger unknownCounter = new AtomicInteger(0);
    private volatile String lastUnknownKey = null; // chave atual usada para fragments sem GUID

    // --- CREDENCIAIS ---
    private static final String CLIENT_ID = System.getenv().getOrDefault("RTO_CLIENTID", "6ad45100841f4a96951f6583e4ba022d57a6565f");
    private static final String USERNAME  = System.getenv().getOrDefault("RTO_USERNAME", "GE-A-00209895-3-19960");
    private static final String PASSWORD  = System.getenv().getOrDefault("RTO_PASSWORD", "senh@-content-hub2025-research-2025@#");
    private static final String APP_ID    = System.getenv().getOrDefault("APP_ID", "256");
    private static final String SERVICE  = "ELEKTRON_DD"; // se precisar fixar serviço

    // --- CONFIG ---
    private static final String RDP_CLOUD_WS = "wss://us-east-1-aws-1-sm.optimized-pricing-api.refinitiv.net:443/WebSocket";
    private static final String NEWS_RIC = "MRN_STORY";

    private final HttpClient http = HttpClient.newHttpClient();
    private final ObjectMapper mapper = new ObjectMapper();
    private final String wsUrlOverride;
    private final int reconnectSeconds;
    private final RtoTokenClient tokenClient;
    private final FileQueueSink sink;

    public NewsWebSocketClient(String wsUrlOverride, int reconnectSeconds, RtoTokenClient tokenClient, FileQueueSink sink) {
        this.wsUrlOverride = wsUrlOverride == null ? "" : wsUrlOverride;
        this.reconnectSeconds = reconnectSeconds;
        this.tokenClient = tokenClient;
        this.sink = sink;
    }

    public void connect() {
        if (closed) return;
        try {
            String endpoint = (wsUrlOverride.isBlank()) ? RDP_CLOUD_WS : wsUrlOverride.trim();
            sink.appendLine("[CONNECTING] " + endpoint);

            WebSocket.Builder b = http.newWebSocketBuilder()
                    .connectTimeout(Duration.ofSeconds(20))
                    .subprotocols("tr_json2");

            this.socket = b.buildAsync(URI.create(endpoint), this).join();
            sink.appendLine("[OPEN] Connected to " + endpoint);
        } catch (java.util.concurrent.CompletionException e) {
            // join() wraps exceptions in CompletionException; inspect cause for handshake
            Throwable cause = e.getCause();
            if (cause instanceof java.net.http.WebSocketHandshakeException) {
                try { sink.appendLine("[HANDSHAKE] status=" + ((java.net.http.WebSocketHandshakeException) cause).getResponse().statusCode()); } catch (Exception ignore) {}
            } else {
                try { sink.appendLine("[ERROR] " + (cause == null ? e.getMessage() : cause.getMessage())); } catch (Exception ignore) {}
            }
            scheduleReconnect();
        } catch (Exception e) {
            try { sink.appendLine("[ERROR] " + e.getMessage()); } catch (Exception ignore) {}
            scheduleReconnect();
        }
    }

    private void scheduleReconnect() {
        if (closed) return;
        try { sink.appendLine("[RECONNECT] New attempt in " + reconnectSeconds + "s"); } catch (Exception ignored) {}
        try { Thread.sleep(reconnectSeconds * 1000L); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
        connect();
    }

    @Override
    public void onOpen(WebSocket webSocket) {
        webSocket.request(1);
        try {
            sink.appendLine("[READY] WebSocket Open");

            String token = tokenClient.getAccessToken();
            String login = ("{" +
                    "\"ID\":1," +
                    "\"Domain\":\"Login\",\"Key\":{\"Name\":\"" + USERNAME + "\",\"NameType\":\"AuthnToken\",\"Elements\":{\"ApplicationId\":\"" + APP_ID + "\",\"Position\":\"127.0.0.1/net\",\"AuthenticationToken\":\"" + token + "\"}}}");
            webSocket.sendText(login, true);
            sink.appendLine("[LOGIN] enviado");
        } catch (Exception ex) {
            try { sink.appendLine("[ERROR] Auth/Login falhou: " + ex.getMessage()); } catch (Exception ignore) {}
            try { webSocket.abort(); } catch (Exception ignore) {}
            scheduleReconnect();
        }
    }


    @Override
    public CompletionStage<?> onText(WebSocket webSocket, CharSequence data, boolean last) {
        try {
            processIncomingMessage(data.toString());
        } catch (Exception e) {
            try { sink.appendLine("[PROCESS-ERROR] " + e.getMessage()); } catch (Exception ignore) {}
        }
        webSocket.request(1);
        return null;
    }

    private void processIncomingMessage(String message) throws IOException {
        var root = mapper.readTree(message);
        if (root.isArray()) {
            for (var msg : root) processSingleMessage(msg);
        } else {
            processSingleMessage(root);
        }
    }

    private void processSingleMessage(JsonNode msg) throws IOException {
        String domain = msg.path("Domain").asText();
        String type   = msg.path("Type").asText();

        if ("Ping".equals(type)) { socket.sendText("{\"Type\":\"Pong\"}", true); return; }

        if ("Login".equalsIgnoreCase(domain)) {
            if ("Refresh".equals(type)) {
                JsonNode st = msg.path("State");
                boolean ok = "Ok".equalsIgnoreCase(st.path("Data").asText())
                        && "Open".equalsIgnoreCase(st.path("Stream").asText());
                if (ok) {
                    loginOpen = true;
                    sink.appendLine("[LOGIN] Open/Ok – assinando MRN");
                    String sub = "{"
                            + "\"ID\":2,"
                            + "\"Domain\":\"NewsTextAnalytics\","
                            + "\"Topic\":[\"BR\"],"
                            + "\"audiences\":["
                            + "\"NP:AGFFP\","
                            + "\"NP:BRS\","
                            + "\"NP:LPCO\","
                            + "\"NP:TRNPT\","
                            + "\"NP:PTCO\","
                            + "\"NP:CTPT\","
                            + "\"NP:P\","
                            + "\"NP:PTGF\","
                            + "\"NP:ESALP\""
                            + "],"
                            + "\"Key\":{\"Name\":\"" + NEWS_RIC + "\",\"Service\":\"" + SERVICE + "\"}"
                            + "}";
                    socket.sendText(sub, true);
                } else {
                    sink.appendLine("[LOGIN] Refresh não-OK: " + st);
                }
            } else if ("Status".equals(type)) {
                sink.appendLine("[LOGIN STATUS] " + msg);
                // se o login fechou com erro de token, force refresh/reconnect
                String code = msg.path("State").path("Code").asText("");
                if (code.contains("UserAccessToAppDenied")) {
                    // força renovar token e reconectar
                    try { socket.abort(); } catch (Exception ignore) {}
                    // opcional: zere token em cache se você guarda (para pegar outro)
                    // tokenClient.reset(); // se você implementar esse método
                    scheduleReconnect();
                }
            }
            return;
        }

        // itens
        if ("NewsTextAnalytics".equalsIgnoreCase(domain)) {
            if (!loginOpen) { sink.appendLine("[WARN] Item antes do login abrir"); return; }
            if ("Refresh".equals(type) || "Update".equals(type)) processMrnFragment(msg);
            else if ("Status".equals(type)) sink.appendLine("[STATUS] " + msg);
        }
    }


    private void processMrnFragment(JsonNode msg) {
        JsonNode fields = msg.path("Fields");
        if (fields.isMissingNode()) return;

        JsonNode fragment = fields.path("FRAGMENT");
        JsonNode fragNum = fields.path("FRAG_NUM");
        JsonNode acumNode = fields.path("ACUM");
        JsonNode guidNode = fields.path("GUID");

        // when FRAGMENT is missing, try to finalize any accumulated fragments via reassembler.forceAssemble
        if (fragment.isMissingNode()) {
            String guid = guidNode.isMissingNode() ? null : guidNode.asText(null);
            try { sink.appendLine("[MRN-FRAGMENT-END] FRAGMENT missing — tentando finalizar montagem para GUID=" + (guid == null ? "null" : guid)); } catch (Exception ignore) {}
            Optional<String> assembled = reassembler.forceAssemble(guid);
            if (assembled.isPresent()) {
                try {
                    String newsJson = decodePayloadFromString(assembled.get());
                    sink.enqueueDecodedNews(newsJson, guid);
                } catch (Exception ex) {
                    try {
                        // diagnostic: preview base64 and first bytes hex
                        String preview = assembled.get().length() > 200 ? assembled.get().substring(0,200) + "..." : assembled.get();
                        String hex = "";
                        try {
                            byte[] raw = Base64.getDecoder().decode(assembled.get());
                            int len = Math.min(8, raw.length);
                            StringBuilder sb = new StringBuilder();
                            for (int i = 0; i < len; i++) sb.append(String.format("%02X ", raw[i]));
                            hex = sb.toString().trim();
                        } catch (Exception ignore) {}
                        sink.appendLine("[MRN-DECODE-ERROR] " + ex.getMessage());
                        sink.appendLine("[MRN-DECODE-DEBUG] preview_base64=" + preview);
                        sink.appendLine("[MRN-DECODE-DEBUG] first_bytes_hex=" + hex);
                    } catch (Exception ignore) {}
                } finally {
                    // se era uma chave temporária, limpa para próxima MRN sem GUID
                    if (guid != null && guid.startsWith("UNKN-")) {
                        lastUnknownKey = null;
                    }
                }
                return;
            } else {
                try { sink.appendLine("[MRN-FINALIZE] Nenhum fragmento acumulado para GUID=" + (guid == null ? "null" : guid)); } catch (Exception ignore) {}
            }
            return;
        }

        int frag = fragNum.isMissingNode() ? 1 : fragNum.asInt(1);
        int acum = acumNode.isMissingNode() ? 0 : acumNode.asInt(0);
        String guid = guidNode.isMissingNode() ? null : guidNode.asText(null);

        // Se GUID for nulo e este é o primeiro fragment, crie uma chave temporária para reagrupamento
        if (guid == null) {
            if (frag == 1) {
                lastUnknownKey = "UNKN-" + unknownCounter.incrementAndGet();
                guid = lastUnknownKey;
            } else {
                // usa a última chave temporária conhecida; se não houver, gera uma nova
                guid = lastUnknownKey == null ? ("UNKN-" + unknownCounter.incrementAndGet()) : lastUnknownKey;
            }
        }

        Optional<String> assembledBase64 = reassembler.addFragment(guid, frag, acum, fragment.asText());

        try { sink.appendLine(String.format("[MRN-FRAGMENT] GUID=%s FRAG_NUM=%d ACUM=%d REASS=%s FRAG_LEN=%d",
                guidNode.isMissingNode() ? "null" : guidNode.asText(null), frag, acum, assembledBase64.isPresent() ? "COMPLETE" : "PARTIAL", fragment.asText().length())); } catch (Exception ignore) {}

        if (assembledBase64.isPresent()) {
            String assembledB64 = assembledBase64.get();
            try {
                String newsJson = decodePayloadFromString(assembledB64);
                sink.enqueueDecodedNews(newsJson, guid);
            } catch (Exception ex) {
                try {
                    // diagnostic: preview base64 and first bytes hex
                    String preview = assembledB64.length() > 200 ? assembledB64.substring(0,200) + "..." : assembledB64;
                    String hex = "";
                    try {
                        byte[] raw = Base64.getDecoder().decode(assembledB64);
                        int len = Math.min(8, raw.length);
                        StringBuilder sb = new StringBuilder();
                        for (int i = 0; i < len; i++) sb.append(String.format("%02X ", raw[i]));
                        hex = sb.toString().trim();
                    } catch (Exception ignore) {}
                    sink.appendLine("[MRN-DECODE-ERROR] " + ex.getMessage());
                    sink.appendLine("[MRN-DECODE-DEBUG] preview_base64=" + preview);
                    sink.appendLine("[MRN-DECODE-DEBUG] first_bytes_hex=" + hex);
                } catch (Exception ignore) {}
            } finally {
                // se era uma chave temporária, limpa para próxima MRN sem GUID
                if (guid != null && guid.startsWith("UNKN-")) {
                    lastUnknownKey = null;
                }
            }
            return;
        }

        // Fallback pragmatic: if ACUM <= 1 we consider this fragment complete and try to decode immediately
        if (acum <= 1) {
            try {
                sink.appendLine("[MRN-FORCE-DECODE] ACUM<=1, tentando decodificar FRAG_NUM=" + frag + " GUID=" + (guid == null ? "null" : guid));
                String base64 = fragment.asText();
                String newsJson = decodePayloadFromString(base64);
                sink.enqueueDecodedNews(newsJson, guid);
            } catch (Exception ex) {
                try {
                    String base64 = fragment.asText();
                    String preview = base64.length() > 200 ? base64.substring(0,200) + "..." : base64;
                    String hex = "";
                    try {
                        byte[] raw = Base64.getDecoder().decode(base64);
                        int len = Math.min(8, raw.length);
                        StringBuilder sb = new StringBuilder();
                        for (int i = 0; i < len; i++) sb.append(String.format("%02X ", raw[i]));
                        hex = sb.toString().trim();
                    } catch (Exception ignore) {}
                    sink.appendLine("[MRN-DECODE-ERROR-FORCE] " + ex.getMessage());
                    sink.appendLine("[MRN-DECODE-DEBUG-FORCE] preview_base64=" + preview);
                    sink.appendLine("[MRN-DECODE-DEBUG-FORCE] first_bytes_hex=" + hex);
                } catch (Exception ignore) {}
            } finally {
                if (guid != null && guid.startsWith("UNKN-")) lastUnknownKey = null;
            }
            return;
        }

        // Caso não esteja completo e não for ACUM<=1, aguardamos fragments adicionais
        try { sink.appendLine("[MRN-WAITING] Aguardando mais fragments para GUID=" + guid); } catch (Exception ignore) {}
    }

    private String decompressGzip(byte[] compressed) throws IOException {
        // Deprecated: manter compatibilidade com código que chama este método? Substituímos por decodeMaybeGzip.
        return decodeMaybeGzip(compressed);
    }

    /**
     * Decodifica bytes que podem ser GZIP-compressed ou texto plain UTF-8.
     * Detecta cabeçalho gzip (0x1F 0x8B). Se não for gzip, devolve new String(bytes, UTF-8).
     */
    private String decodeMaybeGzip(byte[] compressed) throws IOException {
        if (compressed == null) return "";
        if (compressed.length >= 2 && (compressed[0] == (byte)0x1f && compressed[1] == (byte)0x8b)) {
            // é GZIP
            try (ByteArrayInputStream bin = new ByteArrayInputStream(compressed);
                 GZIPInputStream gin = new GZIPInputStream(bin);
                 InputStreamReader r = new InputStreamReader(gin, StandardCharsets.UTF_8);
                 BufferedReader br = new BufferedReader(r)) {
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                return sb.toString();
            }
        }
        // fallback: interpretar como texto UTF-8
        try {
            return new String(compressed, StandardCharsets.UTF_8);
        } catch (Exception ex) {
            // último recurso: Base64-decode não produziu gzip nem texto legível
            throw new IOException("Payload não está em GZIP nem em texto UTF-8 legível", ex);
        }
    }

    /**
     * Tenta decodificar a string que geralmente vem como Base64; se falhar ao decodificar Base64,
     * assume que a string já é JSON/texto e a retorna como está.
     * Se Base64 decodificar, aplica detectGzip/fallback para obter texto final.
     */
    private String decodePayloadFromString(String base64OrRaw) throws IOException {
        if (base64OrRaw == null) return "";
        try {
            byte[] decoded = Base64.getDecoder().decode(base64OrRaw);
            return decodeMaybeGzip(decoded);
        } catch (IllegalArgumentException iae) {
            // não era Base64 — assume que já é texto JSON
            return base64OrRaw;
        }
    }

    @Override
    public CompletionStage<?> onClose(WebSocket webSocket, int statusCode, String reason) {
        try { sink.appendLine("[CLOSE] " + statusCode + ": " + reason); } catch (Exception ignored) {}
        scheduleReconnect();
        return CompletableFuture.completedFuture(null);
    }

    @Override
    public void onError(WebSocket webSocket, Throwable error) {
        try { sink.appendLine("[ERROR] " + (error.getMessage() == null ? error.toString() : error.getMessage())); } catch (Exception ignored) {}
        scheduleReconnect();
    }

    @Override
    public void close() {
        this.closed = true;
        if (this.socket != null) {
            try {
                this.socket.abort();
            } catch (Exception ignore) {}
        }
    }

    public static void main(String[] args) {
        try (NewsWebSocketClient client = new NewsWebSocketClient(null, 30, new RtoTokenClient(CLIENT_ID, USERNAME, PASSWORD), new FileQueueSink())) {
            client.connect();
            new CompletableFuture<Void>().get();
        } catch (Exception e) {
            System.err.println("CRITICAL FAILURE: " + e.getMessage());
        }
    }
}
