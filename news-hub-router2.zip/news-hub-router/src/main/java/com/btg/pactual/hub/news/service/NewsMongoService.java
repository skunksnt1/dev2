package com.btg.pactual.hub.news.service;

import com.btg.pactual.hub.news.dto.NewsDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NewsMongoService {

    private static final Logger log = LoggerFactory.getLogger(NewsMongoService.class);

    @Autowired
    private MongoTemplate mongoTemplate;

    /** Salva uma notícia no MongoDB */
    public void saveNews(NewsDTO dto) {
        try {
            mongoTemplate.save(dto);
            log.info("[NEWS-MONGO] ✅ Notícia salva com sucesso na coleção 'rauters-news'");
        } catch (Exception e) {
            log.error("[NEWS-MONGO-ERROR] ❌ Falha ao salvar notícia: {}", e.getMessage(), e);
        }
    }

    /** Retorna as 20 notícias mais recentes */
    public List<NewsDTO> getRecentNews() {
        try {
            Query query = new Query()
                    .with(Sort.by(Sort.Direction.DESC, "createdAt"))
                    .limit(20);

            List<NewsDTO> newsList = mongoTemplate.find(query, NewsDTO.class);
            log.info("[NEWS-MONGO] 🔍 Retornadas {} notícias recentes", newsList.size());
            return newsList;

        } catch (Exception e) {
            log.error("[NEWS-MONGO-ERROR] ❌ Erro ao buscar notícias recentes: {}", e.getMessage(), e);
            return List.of();
        }
    }
}
