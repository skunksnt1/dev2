# bwp-news-reuters-wsocket

Projeto Spring Boot 3.2.7 (Java 17) para ingestão de notícias Reuters:
- Salva o JSON bruto em `data/mrn/`
- Persiste no MongoDB (banco `content-hub-news`, coleção `news-reuters`)
- Lista as 10 últimas: `GET /api/news/latest`
- Ingestão via POST: `POST /api/news/ingest` (body = JSON bruto)

## Configuração
Defina a região do AWS Secrets Manager e as URIs templated no `application.yml`:
- `btg.aws.secrets.manager.region` (ex: `sa-east-1`)
- `mongodb.news.uri` e `mongodb.chb.uri` (use `{0}` e `{1}` para user/senha)

Secrets esperados:
- `lcontenthub` e `lcontenthubnews` no AWS Secrets Manager, com JSON:
```
{"username":"seu_user","password":"sua_senha"}
```

## Rodar
```
mvn clean spring-boot:run
```

## Endpoints
- `POST /api/news/ingest` — body: JSON
- `GET  /api/news/latest`
- Swagger: `/swagger-ui.html`
