package com.btg.pactual.hub.news.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@Configuration
@EnableMongoRepositories(
        basePackages = "com.btg.pactual.hub.news.repository",
        mongoTemplateRef = MongoConfig.MONGO_TEMPLATE_NEWS
)
public class MongoNewsRepositoriesConfig {}
