package com.btg.pactual.hub.news.service;

import com.btg.pactual.hub.news.model.News;
import com.btg.pactual.hub.news.repository.NewsRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Instant;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class NewsService {

    private final NewsRepository repository;
    private static final Path BASE_DIR = Paths.get("data/mrn");

    public void ingestRawJson(String rawJson) {
        saveToDisk(rawJson);

        ObjectMapper mapper = new ObjectMapper();
        try {
            JsonNode n = mapper.readTree(rawJson);

            News doc = new News();
            String altId = n.path("altId").asText(null);
            doc.setId(altId != null && !altId.isBlank() ? altId : UUID.randomUUID().toString());

            String headline = n.path("headline").asText(null);
            if (headline == null || headline.isBlank()) {
                headline = n.path("title").asText(null);
            }
            doc.setHeadline(headline);

            String body = n.path("body").asText();
            if (body == null || body.isBlank()) {
                body = n.toString();
            }
            doc.setBody(body);

            doc.setReceivedAt(Instant.now());

            repository.save(doc);
        } catch (IOException e) {
            throw new IllegalArgumentException("JSON inválido para ingestão", e);
        }
    }

    private void saveToDisk(String rawJson) {
        try {
            if (!Files.exists(BASE_DIR)) Files.createDirectories(BASE_DIR);
            String fname = "news_" + Instant.now().toEpochMilli() + ".json";
            Files.write(BASE_DIR.resolve(fname), rawJson.getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE_NEW);
        } catch (IOException e) {
            System.err.println("Erro ao salvar arquivo em data/mrn: " + e.getMessage());
        }
    }
}
