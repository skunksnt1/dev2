package com.btg.pactual.hub.news.controller;

import com.btg.pactual.hub.news.model.News;
import com.btg.pactual.hub.news.repository.NewsRepository;
import com.btg.pactual.hub.news.service.NewsService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/news")
@RequiredArgsConstructor
public class NewsController {

    private final NewsService service;
    private final NewsRepository repository;

    @PostMapping("/ingest")
    public ResponseEntity<Void> ingest(@RequestBody String rawJson) {
        service.ingestRawJson(rawJson);
        return ResponseEntity.accepted().build();
    }

    @GetMapping("/latest")
    public ResponseEntity<List<News>> latest() {
        return ResponseEntity.ok(repository.findTop10ByOrderByReceivedAtDesc());
    }
}
