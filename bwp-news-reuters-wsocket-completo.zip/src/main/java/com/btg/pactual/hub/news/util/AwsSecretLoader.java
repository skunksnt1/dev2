package com.btg.pactual.hub.news.util;

import com.amazonaws.services.secretsmanager.AWSSecretsManager;
import com.amazonaws.services.secretsmanager.AWSSecretsManagerClientBuilder;
import com.amazonaws.services.secretsmanager.model.GetSecretValueRequest;
import com.amazonaws.services.secretsmanager.model.GetSecretValueResult;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

public class AwsSecretLoader {

    public static JsonNode getAwsSecret(String region, String secretName) {
        AWSSecretsManager client = AWSSecretsManagerClientBuilder.standard()
                .withRegion(region)
                .build();

        GetSecretValueRequest req = new GetSecretValueRequest().withSecretId(secretName);
        GetSecretValueResult res = client.getSecretValue(req);

        try {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.readTree(res.getSecretString());
        } catch (Exception e) {
            throw new RuntimeException("Erro ao carregar/parsear secret AWS: " + secretName, e);
        }
    }
}
