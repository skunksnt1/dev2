package com.btg.pactual.hub.news.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Data
@Document(collection = "news-reuters")
public class News {
    @Id
    private String id;
    private String headline;
    private String body;
    private Instant receivedAt;
}
