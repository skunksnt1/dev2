package com.btg.pactual.hub.news.config;

import com.btg.pactual.hub.news.util.AwsSecretLoader;
import com.fasterxml.jackson.databind.JsonNode;
import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.text.MessageFormat;

@Configuration
public class MongoConfig {

    private static final String DEFAULT_CHB_DATABASE  = "content-hub";
    private static final String DEFAULT_NEWS_DATABASE = "content-hub-news";

    public static final String MONGO_TEMPLATE_NEWS = "MONGO_TEMPLATE_NEWS";
    public static final String MONGO_TEMPLATE_CHB  = "MONGO_TEMPLATE_CHB";

    private static final String CHB_SECRET_NAME  = "lcontenthub";
    private static final String NEWS_SECRET_NAME = "lcontenthubnews";

    @Value("${btg.aws.secrets.manager.region}")
    private String secretManagerRegion;

    @Value("${mongodb.chb.uri}")
    private String chbTemplateConnectionString;

    @Value("${mongodb.news.uri}")
    private String newsTemplateConnectionString;

    private MongoClientSettings buildSettings(String secretName, String uriTemplate) {
        JsonNode sec = AwsSecretLoader.getAwsSecret(secretManagerRegion, secretName);
        String uri = MessageFormat.format(uriTemplate,
                sec.get("username").asText(),
                sec.get("password").asText());

        System.out.println("[MongoConfig] Conectando em: " + uri.replaceAll("//.*@", "//***:***@"));

        return MongoClientSettings.builder()
                .applyConnectionString(new ConnectionString(uri))
                .build();
    }

    @Primary
    @Bean(name = "MONGO_CLIENT_NEWS")
    public MongoClient mongoClientNews() {
        return MongoClients.create(buildSettings(NEWS_SECRET_NAME, newsTemplateConnectionString));
    }

    @Bean(name = "MONGO_CLIENT_CHB")
    public MongoClient mongoClientChb() {
        return MongoClients.create(buildSettings(CHB_SECRET_NAME, chbTemplateConnectionString));
    }

    @Primary
    @Bean(name = MONGO_TEMPLATE_NEWS)
    public MongoTemplate mongoTemplateNews() {
        return new MongoTemplate(mongoClientNews(), DEFAULT_NEWS_DATABASE);
    }

    @Bean(name = MONGO_TEMPLATE_CHB)
    public MongoTemplate mongoTemplateChb() {
        return new MongoTemplate(mongoClientChb(), DEFAULT_CHB_DATABASE);
    }
}
