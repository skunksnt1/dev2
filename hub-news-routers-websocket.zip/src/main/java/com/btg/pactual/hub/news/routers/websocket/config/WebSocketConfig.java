package com.btg.pactual.hub.news.routers.websocket.config;

import com.btg.pactual.hub.news.routers.websocket.client.NewsWebSocketClient;
import com.btg.pactual.hub.news.routers.websocket.client.TokenClient;
import com.btg.pactual.hub.news.routers.websocket.queue.FileQueueSink;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.beans.factory.annotation.Value;

@Configuration
public class WebSocketConfig {

    @Bean
    public TokenClient tokenClient(
            @Value("${news.auth.url:}") String authUrl,
            @Value("${news.auth.username:}") String username,
            @Value("${news.auth.password:}") String password,
            @Value("${news.auth.clientId:}") String clientId,
            @Value("${news.auth.clientSecret:}") String clientSecret,
            @Value("${news.auth.scope:}") String scope,
            @Value("${news.auth.grantType:client_credentials}") String grantType
    ) {
        return new TokenClient(authUrl, username, password, clientId, clientSecret, scope, grantType);
    }

    @Bean
    public FileQueueSink fileQueueSink(@Value("${output.file:news-output.txt}") String filename) {
        return new FileQueueSink(filename);
    }

    @Bean
    public NewsWebSocketClient newsWebSocketClient(
            @Value("${news.wsUrl}") String wsUrl,
            @Value("${reconnect.seconds:30}") int reconnectSeconds,
            TokenClient tokenClient,
            FileQueueSink sink
    ) {
        return new NewsWebSocketClient(wsUrl, reconnectSeconds, tokenClient, sink);
    }

    @Bean
    public ApplicationRunner startWs(NewsWebSocketClient client) {
        return args -> client.connect();
    }
}
