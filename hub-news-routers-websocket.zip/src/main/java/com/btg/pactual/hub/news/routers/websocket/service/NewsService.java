package com.btg.pactual.hub.news.routers.websocket.service;

import com.btg.pactual.hub.news.routers.websocket.queue.FileQueueSink;
import org.springframework.stereotype.Service;

@Service
public class NewsService {
    private final FileQueueSink sink;
    public NewsService(FileQueueSink sink) { this.sink = sink; }
    public void process(String message) throws Exception { sink.appendLine("[SERVICE] " + message); }
}
