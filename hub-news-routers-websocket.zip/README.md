# hub-news-routers-websocket

Cliente WebSocket (Java 21 + Spring Boot) para consumir notícias e salvar em arquivo (simulando fila).

## Executar
```bash
mvn spring-boot:run
# ou empacotar
mvn clean package
java -jar target/hub-news-routers-websocket-1.0.0.jar
```

## Variáveis (application.yml ou env)
- WS_URL: URL do WebSocket
- AUTH_URL, AUTH_CLIENT_ID, AUTH_CLIENT_SECRET, AUTH_SCOPE, AUTH_GRANT_TYPE, AUTH_USERNAME, AUTH_PASSWORD
- OUTPUT_FILE: arquivo de saída (default: news-output.txt)
- RECONNECT_MAX_SECONDS: intervalo para reconexão
