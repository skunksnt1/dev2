package com.btg.pactual.hub.news.config;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

/**
 * Stub para auto-start do WebSocket. Mantenho desabilitado por padrão.
 * Quando quiser ligar, set news.websocket.enabled=true
 * e implemente a invocação ao seu cliente WS aqui.
 */
@Component
@ConditionalOnProperty(value = "news.websocket.enabled", havingValue = "true", matchIfMissing = false)
public class WebSocketAutoStarter implements ApplicationRunner {
    @Override
    public void run(ApplicationArguments args) {
        System.out.println("[WS-AUTO] news.websocket.enabled=true -> Inicie seu cliente WS aqui.");
        // TODO: injetar e chamar seu NewsWebSocketClient.start()
        // Ex.: client.start();
    }
}
