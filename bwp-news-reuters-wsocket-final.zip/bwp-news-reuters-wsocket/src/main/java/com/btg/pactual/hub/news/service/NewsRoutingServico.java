package com.btg.pactual.hub.news.service;
import com.btg.pactual.hub.news.builder.NewsBuilder;
import com.btg.pactual.hub.news.constants.AppConstantes;
import com.btg.pactual.hub.news.dto.NewsDTO;
import com.btg.pactual.hub.news.model.NewsDocumento;
import com.btg.pactual.hub.news.repository.NewsRepositorio;
import lombok.RequiredArgsConstructor; import org.springframework.stereotype.Service;
import java.io.*; @Service @RequiredArgsConstructor
public class NewsRoutingServico {
  private final NewsRepositorio repository; private final NewsBuilder builder;
  public void processIncomingJson(String rawJson) {
    if (AppConstantes.SAVE_TO_FILE) saveToFile(rawJson); else saveToMongo(rawJson);
  }
  private void saveToFile(String rawJson) {
    try {
      java.io.File dir = new java.io.File(AppConstantes.SAVE_PATH); if (!dir.exists()) dir.mkdirs();
      String fileName = AppConstantes.SAVE_PATH + "news_" + System.currentTimeMillis() + ".json";
      try (java.io.FileWriter fw = new java.io.FileWriter(fileName)) { fw.write(rawJson); }
      System.out.println("[SAVE_TO_FILE] " + fileName);
    } catch (IOException e) { System.err.println("Erro ao salvar arquivo: " + e.getMessage()); }
  }
  private void saveToMongo(String rawJson) {
    try {
      NewsDTO dto = builder.fromMrn(rawJson);
      NewsDocumento doc = NewsDocumento.builder()
        .id(dto.getId()).language(dto.getLanguage()).headline(dto.getHeadline())
        .body(dto.getBody()).audiences(dto.getAudiences()).receivedAt(dto.getReceivedAt())
        .build();
      repository.save(doc);
      System.out.println("[SAVE_TO_MONGO] " + dto.getId());
    } catch (Exception e) { System.err.println("Erro ao salvar no Mongo: " + e.getMessage()); }
  }
}
