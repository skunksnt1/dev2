package com.btg.pactual.hub.news.dto;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import java.time.Instant;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class NewsDTO {
  @NotBlank private String id;
  private String language; private String headline; private String body;
  private java.util.List<String> audiences;
  private FonteDTO source;
  private java.util.List<ImagemDTO> images;
  private Instant receivedAt;
}
