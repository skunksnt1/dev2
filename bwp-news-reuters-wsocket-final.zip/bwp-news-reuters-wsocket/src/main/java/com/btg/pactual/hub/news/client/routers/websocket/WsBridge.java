package com.btg.pactual.hub.news.client.routers.websocket;

import com.btg.pactual.hub.news.service.WsMensagemHandler;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * Ponte simples Spring para ser usada dentro do seu cliente WS existente.
 * Sempre que montar a mensagem MRN final, chame bridge.onMessage(json);
 */
@Component
@RequiredArgsConstructor
public class WsBridge {

    private final WsMensagemHandler handler;

    public void onMessage(String rawJson) {
        handler.handle(rawJson);
    }
}
