package com.btg.pactual.hub.news.controller;
import org.springframework.web.bind.annotation.*; @RestController
public class SaudeControle { @GetMapping("/health") public String ok(){ return "ok"; } }
