package com.btg.pactual.hub.news.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * Componente simples para ser chamado sempre que UMA mensagem MRN completa for recebida
 * pelo seu cliente de WebSocket (após remontar fragmentos).
 * Ex.: wsMessageHandler.handle(rawJson);
 */
@Component
@RequiredArgsConstructor
public class WsMensagemHandler {

    private final NewsRoutingServico routing;

    /** Recebe o JSON bruto MRN e delega para salvar (arquivo ou Mongo) */
    public void handle(String rawJson) {
        routing.processIncomingJson(rawJson);
    }
}
