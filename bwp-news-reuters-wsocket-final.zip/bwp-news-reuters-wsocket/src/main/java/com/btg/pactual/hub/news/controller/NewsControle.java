
package com.btg.pactual.hub.news.controller;

import com.btg.pactual.hub.news.model.NewsDocumento;
import com.btg.pactual.hub.news.repository.NewsRepositorio;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/news")
@RequiredArgsConstructor
public class NewsControle {

    private final NewsRepositorio repositorio;

    /** Endpoint existente de ingestão omitido (mantido no projeto anterior) */

    /** Novo endpoint Swagger para listar as últimas 10 notícias */
    @GetMapping("/ultimas")
    public ResponseEntity<List<NewsDocumento>> ultimasNoticias() {
        List<NewsDocumento> noticias = repositorio
            .findAll(PageRequest.of(0, 10, Sort.by(Sort.Direction.DESC, "receivedAt")))
            .getContent();
        return ResponseEntity.ok(noticias);
    }
}
