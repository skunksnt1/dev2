package com.btg.pactual.hub.news;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BwpNewsReutersWsocketAplicacao {
    public static void main(String[] args) {
        SpringApplication.run(BwpNewsReutersWsocketAplicacao.class, args);
    }
}
