package com.btg.pactual.hub.news.repository;

import com.btg.pactual.hub.news.model.News;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface NewsRepository extends MongoRepository<News, String> {
}
