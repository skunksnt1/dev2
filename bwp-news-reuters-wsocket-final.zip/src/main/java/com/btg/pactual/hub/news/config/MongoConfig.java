package com.btg.pactual.hub.news.config;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.*;
import org.springframework.data.mongodb.core.MongoTemplate;

@Configuration
public class MongoConfig {

    public static final String MONGO_TEMPLATE_NEWS = "MONGO_TEMPLATE_NEWS";

    @Value("${mongodb.news.uri}")
    private String mongoUri;

    @Primary
    @Bean
    public MongoClient mongoClientNews() {
        System.out.println("[MongoConfig] Conectando em: " + mongoUri.replaceAll("//.*@", "//***:***@"));
        return MongoClients.create(mongoUri);
    }

    @Primary
    @Bean(name = MONGO_TEMPLATE_NEWS)
    public MongoTemplate mongoTemplateNews() {
        return new MongoTemplate(mongoClientNews(), "content-hub-news");
    }
}
