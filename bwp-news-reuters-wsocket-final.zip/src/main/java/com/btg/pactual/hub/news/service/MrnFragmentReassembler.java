package com.btg.pactual.hub.news.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class MrnFragmentReassembler {

    private final FileQueueSink sink;

    // Chame este método quando receber o JSON da MRN
    public void onNewsReceived(String jsonMessage) {
        System.out.println("[MRN] Recebendo notícia...");
        sink.appendLine(jsonMessage);
    }
}
