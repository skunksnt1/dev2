package com.btg.pactual.hub.news.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "news-reuters")
public class News {
    @Id
    private String id;

    private String altId;
    private String title;
    private String body;
    private String language;
    private String provider;
    private String category;
    private Instant publishedAt;
}
