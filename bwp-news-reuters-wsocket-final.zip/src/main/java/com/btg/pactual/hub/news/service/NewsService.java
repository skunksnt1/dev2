package com.btg.pactual.hub.news.service;

import com.btg.pactual.hub.news.model.News;
import com.btg.pactual.hub.news.repository.NewsRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class NewsService {
    private final NewsRepository repository;

    public List<News> listAll() {
        return repository.findAll();
    }
}
