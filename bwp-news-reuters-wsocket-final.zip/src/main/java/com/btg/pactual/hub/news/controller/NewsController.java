package com.btg.pactual.hub.news.controller;

import com.btg.pactual.hub.news.model.News;
import com.btg.pactual.hub.news.service.NewsService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/news")
@RequiredArgsConstructor
public class NewsController {

    private final NewsService newsService;

    @GetMapping
    public List<News> listAll() {
        return newsService.listAll();
    }
}
