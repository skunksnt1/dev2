package com.btg.pactual.hub.news.service;

import com.btg.pactual.hub.news.model.News;
import com.btg.pactual.hub.news.repository.NewsRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.UUID;

@Component
@RequiredArgsConstructor
public class FileQueueSink {

    private final NewsRepository repository;
    private final ObjectMapper mapper = new ObjectMapper();

    public void appendLine(String jsonNews) {
        try {
            JsonNode n = mapper.readTree(jsonNews);

            News news = News.builder()
                    .id(n.path("altId").asText(UUID.randomUUID().toString()))
                    .altId(n.path("altId").asText(null))
                    .title(n.path("title").asText(null))
                    .body(n.path("body").asText(jsonNews))
                    .language(n.path("language").asText("pt"))
                    .provider(n.path("provider").asText("Reuters"))
                    .category(n.path("category").asText(null))
                    .publishedAt(Instant.now())
                    .build();

            repository.save(news);
            System.out.println("[MongoDB] Notícia salva com sucesso: " + news.getId());
        } catch (Exception e) {
            System.err.println("[MongoDB] Erro ao salvar notícia: " + e.getMessage());
        }
    }
}
