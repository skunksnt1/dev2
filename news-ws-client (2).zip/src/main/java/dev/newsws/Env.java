package dev.newsws;
import java.util.Optional;
public final class Env {
    public static String get(String key, String def) {
        return Optional.ofNullable(System.getenv(key)).filter(s -> !s.isBlank()).orElse(def);
    }
    public static boolean getBool(String key, boolean def) {
        String v = System.getenv(key);
        return v == null ? def : v.equalsIgnoreCase("true") || v.equals("1");
    }
    public static int getInt(String key, int def) {
        try { return Integer.parseInt(System.getenv(key)); } catch (Exception e) { return def; }
    }
}