package dev.newsws;
import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
public class FileSink implements AutoCloseable {
    private final Path file;
    private final DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    public FileSink(String filename) throws IOException {
        this.file = Path.of(filename);
        if (!Files.exists(file)) Files.createFile(file);
        appendLine("===== START at " + LocalDateTime.now().format(fmt) + " =====");
    }
    public synchronized void appendLine(String line) throws IOException {
        Files.writeString(file, line + System.lineSeparator(), StandardOpenOption.APPEND);
    }
    @Override
    public void close() throws IOException { appendLine("===== END ====="); }
}