package dev.newsws;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.util.Optional;
import java.util.concurrent.*;
public class NewsWebSocket implements WebSocket.Listener, AutoCloseable {
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15)).build();
    private final TokenClient tokenClient;
    private final FileSink sink;
    private final String wsUrl;
    private final boolean bearerInHeader;
    private final int reconnectMaxSec;
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
    private volatile WebSocket socket;
    private volatile boolean closed = false;
    public NewsWebSocket(TokenClient tokenClient, FileSink sink) {
        this.tokenClient = tokenClient;
        this.sink = sink;
        this.wsUrl = Env.get("WS_URL", "");
        this.bearerInHeader = Env.getBool("WS_HEADER_AUTHORIZATION_BEARER", true);
        this.reconnectMaxSec = Env.getInt("RECONNECT_MAX_SECONDS", 60);
    }
    public void connect() { doConnect(); }
    private void doConnect() {
        try {
            WebSocket.Builder builder = http.newWebSocketBuilder().connectTimeout(Duration.ofSeconds(20));
            if (tokenClient != null && tokenClient.isConfigured() && bearerInHeader)
                builder.header("Authorization", "Bearer " + tokenClient.getAccessToken());
            this.socket = builder.buildAsync(URI.create(wsUrl), this).join();
            sink.appendLine("[OPEN] Connected to " + wsUrl);
        } catch (Exception e) {
            try { sink.appendLine("[ERROR] " + e.getMessage()); } catch (Exception ignored) {}
            scheduleReconnect();
        }
    }
    private void scheduleReconnect() {
        if (closed) return;
        scheduler.schedule(this::doConnect, reconnectMaxSec, TimeUnit.SECONDS);
    }
    @Override
    public void onOpen(WebSocket webSocket) {
        webSocket.request(1);
        try { sink.appendLine("[READY] WebSocket Open"); } catch (Exception ignored) {}
    }
    @Override
    public CompletionStage<?> onText(WebSocket webSocket, CharSequence data, boolean last) {
        try { sink.appendLine("[MSG] " + data); } catch (Exception ignored) {}
        webSocket.request(1);
        return null;
    }
    @Override
    public CompletionStage<?> onClose(WebSocket webSocket, int statusCode, String reason) {
        try { sink.appendLine("[CLOSE] " + statusCode + ": " + reason); } catch (Exception ignored) {}
        scheduleReconnect();
        return CompletableFuture.completedFuture(null);
    }
    @Override
    public void onError(WebSocket webSocket, Throwable error) {
        try { sink.appendLine("[ERROR] " + Optional.ofNullable(error.getMessage()).orElse(error.toString())); } catch (Exception ignored) {}
        scheduleReconnect();
    }
    @Override
    public void close() throws Exception {
        closed = true;
        if (socket != null) socket.abort();
        scheduler.shutdownNow();
    }
}