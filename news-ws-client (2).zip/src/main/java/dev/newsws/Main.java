package dev.newsws;
public class Main {
    public static void main(String[] args) throws Exception {
        String outFile = Env.get("OUTPUT_FILE", "news-output.txt");
        try (FileSink sink = new FileSink(outFile)) {
            TokenClient tokenClient = new TokenClient();
            NewsWebSocket ws = new NewsWebSocket(tokenClient, sink);
            ws.connect();
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                try { ws.close(); } catch (Exception ignored) {}
            }));
            Thread.currentThread().join();
        }
    }
}