package dev.newsws;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;
public class TokenClient {
    private final HttpClient http = HttpClient.newHttpClient();
    private final ObjectMapper om = new ObjectMapper();
    private final String authUrl = Env.get("AUTH_URL", "");
    private final String username = Env.get("AUTH_USERNAME", "");
    private final String password = Env.get("AUTH_PASSWORD", "");
    private final String clientId = Env.get("AUTH_CLIENT_ID", "");
    private final String clientSecret = Env.get("AUTH_CLIENT_SECRET", "");
    private final String scope = Env.get("AUTH_SCOPE", "");
    private final String grantType = Env.get("AUTH_GRANT_TYPE", "client_credentials");
    private String refreshToken = null;
    private long expiryEpochSeconds = 0L;
    private String accessToken = null;
    public boolean isConfigured() { return !authUrl.isBlank(); }
    public synchronized String getAccessToken() throws IOException, InterruptedException {
        long now = System.currentTimeMillis() / 1000L;
        if (accessToken != null && now < expiryEpochSeconds - 30) return accessToken;
        if (refreshToken != null) {
            try { return requestToken("refresh_token", Map.of("refresh_token", refreshToken)); } catch (Exception ignore) {}
        }
        return requestToken(grantType, Map.of());
    }
    private String formEncode(Map<String, String> map) {
        StringBuilder sb = new StringBuilder();
        boolean first = true;
        for (var e : map.entrySet()) {
            if (!first) sb.append('&');
            sb.append(URLEncoder.encode(e.getKey(), StandardCharsets.UTF_8)).append('=')
              .append(URLEncoder.encode(e.getValue(), StandardCharsets.UTF_8));
            first = false;
        }
        return sb.toString();
    }
    private String requestToken(String selectedGrant, Map<String, String> extras) throws IOException, InterruptedException {
        Map<String, String> body = new LinkedHashMap<>();
        body.put("client_id", clientId);
        if (!clientSecret.isBlank()) body.put("client_secret", clientSecret);
        if (!scope.isBlank()) body.put("scope", scope);
        body.put("grant_type", selectedGrant);
        if (selectedGrant.equals("password")) {
            body.put("username", username);
            body.put("password", password);
        }
        body.putAll(extras);
        HttpRequest req = HttpRequest.newBuilder(URI.create(authUrl))
                .timeout(Duration.ofSeconds(20))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(formEncode(body)))
                .build();
        HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() / 100 != 2)
            throw new IOException("Auth failed: HTTP " + resp.statusCode() + "\n" + resp.body());
        JsonNode json = om.readTree(resp.body());
        accessToken = json.path("access_token").asText();
        int expiresIn = json.path("expires_in").asInt(300);
        expiryEpochSeconds = (System.currentTimeMillis() / 1000L) + expiresIn;
        refreshToken = json.path("refresh_token").asText(null);
        return accessToken;
    }
}