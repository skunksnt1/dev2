package com.btg.pactual.hub.news.repository;

import com.btg.pactual.hub.news.model.NewsDocumento;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface NewsRepositorio extends MongoRepository<NewsDocumento, String> {
    Optional<NewsDocumento> findByIdEquals(String id);
}
